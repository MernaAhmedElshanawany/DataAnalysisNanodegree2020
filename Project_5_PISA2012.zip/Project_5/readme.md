# An overview over PISA2012 dataset:
## By: Merna Ahmed Elshanawany


## Dataset

PISA is a survey of students' skills and knowledge as they approach the end of compulsory education. 
Around 510,000 students in 65 economies took part in the PISA 2012 assessment of reading, mathematics and science representing about 28 million 15-year-olds globally. Of those economies, 44 took part in an assessment of creative problem solving and 18 in an assessment of financial literacy.
In our dataset here, We have 485490 entries(rows) and 636 columns. The data types of our data set are either floats, integers or objects. 


## Summary of Findings

* Mexico is the highest participating country in PISA surveys with the highest count (35000) followed by Italy (31250) and then Spain(25000) , Canada (21250) and Brazil(19000).
* There is no significant difference between male and female students regarding their international grades. They seem to have similar probability of scoring the same with a very slight higher probability in females than males. 
* The study programs 96, 7 & 13 show least probability for the students to achieve higher grades, while program 12 has the highest probability. 
* The study programs 9 and 10 have the widest range of grades followed by program 13 then programs 8 and 11.
* We can see lots of outliers in almost all study programs which need further investigation for better analysis. 
* Most students Agree to their interest in Maths (acount that is a little bit less than 140000) then they seeem to disagree to being interested in maths (around 90000) then strongly agree and finally strongly disagreeing to maths interest which is pretty much interesting as a distribution, because we normally expect that the agreeing students to math interest should be somehow close to those strongly agreeing to the same idea - and the other way around -, but exceptionally it doesn't look like this way here.
* We needed to perform some wrangling steps to visualize the distributuin of the students grades in reading, maths and science. 
* Most of the students score in maths, reading and science in a range between 200 and 800 grades. 
* Maths, Reading and Science score all apear to be normally distributed in our histograms among students. 
* A strong positive correlation can be seen here between our 3 variables (Math grades, reading grades and science grades) with the strongest correlation between Science grades and Math grades (r= 0.93).
* In the Mother status bar chart, the working full time mother has the highest counts followed by the mother that is retired or doing home duties and finally followed by working part time mothers.
* In the Father status bar chart, the wroking full time father has the highest count (>175000) even higher than the working full time mother in the first bar chart (a bit less than 120000) , but all other fathers (either working part time or not working or doing home duties) appear to be much less than a mother doing home duties or a retired mother. 
* In both clustered bar charts, the program 10 appears to have the highest count followed by program 9. 


## Key Insights for Presentation

* Concerning maths interest among students, Most students Agree to their interest in Maths (a little bit less than 140000) then they seeem to disagree to being interested in maths (around 90000) then strongly agree and finally strongly disagreeing to maths interest. This is pretty much interesting as a distribution, because we normally expect that the agreeing students to math interest should be somehow close to those strongly agreeing to the same idea - and the other way around -, but exceptionally it doesn't look like this way here.
* Concerning the national study programs and their relationship with international grades, the study programs 96, 7 & 13 show least probability for the students to achieve higher grades, while program 12 has the highest probability. Programs 9 and 10 have the widest range of grades followed by program 13 then programs 8 and 11.
* A strong positive correlation between our 3 variables (Math grades, reading grades and science grades) with the strongest correlation between Science grades and Math grades with the strongest correlation between Science grades and Math grades (r= 0.93).


## Feedback 

I showed my husband the visualizations and tried to explain to him what each visualization meant and took his feedback concerning how each visualization looked, do they convey the message needed and if they were easy to understand at first sight or not.
I should say this was a very enriching and useful step for me to make and I would stick in the future on taking feedback from others because it was very enlightening.

Let me tell you some of the comments he highlighted that made me modify my visualizations in order to be much easier to interpret and convey they message, 
* He was bothered from rotating the too long xticks in my last clustered bar chart and he said it made the process of understanding the clustered bar chart not so smooth so I searched and found my answer in stack overflow where I changed the xticks into shorter names so that I can avoid rotation.
* In the same clustered bar chart , my legends weren't aligned on the top right at first, he was the one who told me to align it for better view of the whole chart. 